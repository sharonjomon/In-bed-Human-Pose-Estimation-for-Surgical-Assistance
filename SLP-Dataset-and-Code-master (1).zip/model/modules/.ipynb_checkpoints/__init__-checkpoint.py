from model.modules.DeepPose import *
from model.modules.ChainedPredictions import *
from model.modules.StackedHourGlass import *
from model.modules.PoseAttention import *
from model.modules.PyraNet import *
