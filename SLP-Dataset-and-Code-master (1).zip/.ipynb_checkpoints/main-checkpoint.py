'''
2d pose estimation handling
'''

from data.SLP_RD import SLP_RD
from data.SLP_FD import SLP_FD
import utils.vis as vis
import utils.utils as ut
import numpy as np
import opt
import cv2
import torch
import json
import shutil
from os import path
import os
from utils.logger import Colorlogger
from utils.utils_tch import get_model_summary
from core.loss import JointsMSELoss
from torch.utils.data import DataLoader
from torch.optim import Adam
import time
from utils.utils_ds import accuracy, flip_back
from utils.visualizer import Visualizer

# opts outside?
opts = opt.parseArgs()
if 'depth' in opts.mod_src[0]:  # the leading modalities, only depth use tight bb other raw image size
	opts.if_bb = True  # not using bb, give ori directly
else:
	opts.if_bb = False  #
exec('from model.{} import get_pose_net'.format(opts.model))  # pose net in
opts = opt.aug_opts(opts)  # add necesary opts parameters   to it
# opt.print_options(opts)



def train(loader, ds_rd, model, criterion, optimizer, epoch, n_iter=-1, logger=None, opts=None, visualizer=None, device="cpu"):
	'''
	iter through epoch , return rst{'acc', loss'} each as list can be used outside for updating.
	:param loader:
	:param model:
	:param criterion:
	:param optimizer:
	:param epoch:  for print infor
	:param n_iter: the iteration wanted, -1 for all iters
	:param opts: keep some additional controls
	:param visualizer: for visualizer
	:return:
	'''
	batch_time = ut.AverageMeter()
	data_time = ut.AverageMeter()
	losses = ut.AverageMeter()
	acc = ut.AverageMeter()

	# switch to train mode
	model.train()
	end = time.time()
	li_loss = []
	li_acc = []
	for i, inp_dct in enumerate(loader):
		# get items
		if i>=n_iter and n_iter>0:    # break if iter is set and i is greater than that
			break
		input = inp_dct['pch'].to(device, non_blocking=True)
		target = inp_dct['hms'].to(device, non_blocking=True)     # 14 x 64 x 1??
		target_weight = inp_dct['joints_vis'].to(device, non_blocking=True)

		# measure data loading time     weight, visible or not
		data_time.update(time.time() - end)

		# compute output
		outputs = model(input)      # no need to cuda it?

		target = target.to(device, non_blocking=True)
		target_weight = target_weight.to(device, non_blocking=True)

		if isinstance(outputs, list):       # list multiple stage version
			loss = criterion(outputs[0], target, target_weight)
			for output in outputs[1:]:
				loss += criterion(output, target, target_weight)
		else:
			output = outputs
			loss = criterion(output, target, target_weight)


		# compute gradient and do update step
		optimizer.zero_grad()
		loss.backward()
		optimizer.step()

		# measure accuracy and record loss
		losses.update(loss.item(), input.size(0))
		_, avg_acc, cnt, pred = accuracy(output.detach().cpu().numpy(),
		                                 target.detach().cpu().numpy())  # hm directly, with normalize with 1/10 dim,  pck0.5,  cnt: n_smp,  pred
		acc.update(avg_acc, cnt)  # keep average acc

		if visualizer and 0 == i % opts.update_html_freq:     # update current result, get vis dict
			n_jt = ds_rd.joint_num_ori
			mod0 = opts.mod_src[0]
			mean = ds_rd.means[mod0]
			std = ds_rd.stds[mod0]
			img_patch_vis = ut.ts2cv2(input[0], mean, std)  # to CV BGR, mean std control channel detach inside
			# pseudo change
			# Apply colormap only if defined for this modality
			cm_name = ds_rd.dct_clrMap.get(mod0, None)
			if cm_name is not None and isinstance(cm_name, str):  # not None or empty
				cm = getattr(cv2, cm_name)
				img_patch_vis = cv2.applyColorMap(img_patch_vis, cm)[..., ::-1]  # convert BGR->RGB
			# else: leave img_patch_vis as is for RGB

			# get pred
			pred2d_patch = np.ones((n_jt, 3))  # 3rd for  vis
			pred2d_patch[:, :2] = pred[0] / opts.out_shp[0] * opts.sz_pch[1]
			img_skel = vis.vis_keypoints(img_patch_vis, pred2d_patch, ds_rd.skels_idx)

			hm_gt = target[0].cpu().detach().cpu().numpy().sum(axis=0)    # HXW
			hm_gt = ut.normImg(hm_gt)

			hm_pred = output[0].detach().cpu().numpy().sum(axis=0)
			hm_pred = ut.normImg(hm_pred)
			img_cb = vis.hconcat_resize([img_skel, hm_gt, hm_pred])
			vis_dict = {'img_cb': img_cb}
			visualizer.display_current_results(vis_dict, epoch, False)

		# measure elapsed time
		batch_time.update(time.time() - end)
		end = time.time()

		if i % opts.print_freq == 0:
			msg = 'Epoch: [{0}][{1}/{2}]\t' \
			      'Time {batch_time.val:.3f}s ({batch_time.avg:.3f}s)\t' \
			      'Speed {speed:.1f} samples/s\t' \
			      'Data {data_time.val:.3f}s ({data_time.avg:.3f}s)\t' \
			      'Loss {loss.val:.5f} ({loss.avg:.5f})\t' \
			      'Accuracy {acc.val:.3f} ({acc.avg:.3f})'.format(
				epoch, i, len(loader), batch_time=batch_time,
				speed=input.size(0) / batch_time.val,
				data_time=data_time, loss=losses, acc=acc)
			logger.info(msg)
			li_loss.append(losses.val)   # the current loss
			li_acc.append(acc.val)

	return {'losses':li_loss, 'accs':li_acc}


def validate(loader, ds_rd, model, criterion, n_iter=-1, logger=None, opts=None, if_svVis=False, visualizer=None, device="cpu"):
	'''
	loop through loder, all res, get preds and gts and normled dist.
	With flip test for higher acc.
	for preds, bbs, jts_ori, jts_weigth out, recover preds_ori, dists_nmd, pckh( dist and joints_vis filter, , print, if_sv then save all these
	:param loader:
	:param ds_rd: the reader, givens the length and flip pairs
	:param model:
	:param criterion:
	:param optimizer:
	:param epoch:
	:param n_iter:
	:param logger:
	:param opts:
	:return:
	'''
	batch_time = ut.AverageMeter()
	losses = ut.AverageMeter()
	acc = ut.AverageMeter()

	# switch to evaluate mode
	model.eval()

	num_samples = ds_rd.n_smpl
	n_jt = ds_rd.joint_num_ori

	# to accum rst
	preds_hm = []
	bbs = []
	li_joints_ori = []
	li_joints_vis = []
	li_l_std_ori = []
	with torch.no_grad():
		end = time.time()
		for i, inp_dct in enumerate(loader):
			# compute output
			input = inp_dct['pch'].to(device, non_blocking=True)
			target = inp_dct['hms'].to(device, non_blocking=True)
			target_weight = inp_dct['joints_vis'].to(device, non_blocking=True)
			bb = inp_dct['bb'].to(device, non_blocking=True)
			joints_ori = inp_dct['joints_ori'].to(device, non_blocking=True)
			l_std_ori = inp_dct['l_std_ori'].to(device, non_blocking=True)
			if i>= n_iter and n_iter>0:     # limiting iters
				break
			outputs = model(input)
			if isinstance(outputs, list):
				output = outputs[-1]
			else:
				output = outputs
			output_ori = output.clone()     # original output of original image
			if opts.if_flipTest:
				input_flipped = input.flip(3).clone()       # flipped input
				outputs_flipped = model(input_flipped)      # flipped output
				if isinstance(outputs_flipped, list):
					output_flipped = outputs_flipped[-1]
				else:
					output_flipped = outputs_flipped
				output_flipped_ori = output_flipped.clone() # hm only head changed? not possible??
				output_flipped = flip_back(output_flipped.cpu().numpy(),
				                           ds_rd.flip_pairs)
				output_flipped = torch.from_numpy(output_flipped.copy()).to(device) # N x n_jt xh x w tch

				# feature is not aligned, shift flipped heatmap for higher accuracy
				if_shiftHM = True  # no idea why
				if if_shiftHM:      # check original
					# print('run shift flip')
					output_flipped[:, :, :, 1:] = \
						output_flipped.clone()[:, :, :, 0:-1]

				output = (output + output_flipped) * 0.5

			target = target.to(device, non_blocking=True)
			target_weight = target_weight.to(device, non_blocking=True)
			loss = criterion(output, target, target_weight)

			num_images = input.size(0)
			# measure accuracy and record loss
			losses.update(loss.item(), num_images)
			_, avg_acc, cnt, pred_hm = accuracy(output.cpu().numpy(),
			                                 target.cpu().numpy())
			acc.update(avg_acc, cnt)

			# preds can be furhter refined with subpixel trick, but it is already good enough.
			# measure elapsed time
			batch_time.update(time.time() - end)
			end = time.time()

			# keep rst
			preds_hm.append(pred_hm)        # already numpy, 2D
			bbs.append(bb.cpu().numpy())
			li_joints_ori.append(joints_ori.cpu().numpy())
			li_joints_vis.append(target_weight.cpu().numpy())
			li_l_std_ori.append(l_std_ori.cpu().numpy())

			if if_svVis and 0 == i % opts.svVis_step:
				sv_dir = opts.vis_test_dir  # exp/vis/Human36M
				# batch version
				mod0 = opts.mod_src[0]
				mean = ds_rd.means[mod0]
				std = ds_rd.stds[mod0]
				img_patch_vis = ut.ts2cv2(input[0], mean, std) # to CV BGR
				img_patch_vis_flipped = ut.ts2cv2(input_flipped[0], mean, std) # to CV BGR
				# pseudo change
				cm_name = ds_rd.dct_clrMap.get(mod0, None) 
				if isinstance(cm_name, str):
					cm = getattr(cv2, cm_name)
					img_patch_vis = cv2.applyColorMap(img_patch_vis, cm)
					img_patch_vis_flipped = cv2.applyColorMap(img_patch_vis_flipped, cm)

				# original version get img from the ds_rd , different size , plot ing will vary from each other
				# warp preds to ori
				# draw and save  with index.

				idx_test = i * opts.batch_size  # image index
				skels_idx = ds_rd.skels_idx
				# get pred2d_patch
				pred2d_patch = np.ones((n_jt, 3))  # 3rd for  vis
				pred2d_patch[:,:2] = pred_hm[0] / opts.out_shp[0] * opts.sz_pch[1]      # only first
				vis.save_2d_skels(img_patch_vis, pred2d_patch, skels_idx, sv_dir, suffix='-'+mod0,
				                  idx=idx_test)  # make sub dir if needed, recover to test set index by indexing.
				# save the hm images. save flip test
				hm_ori = ut.normImg(output_ori[0].cpu().numpy().sum(axis=0))    # rgb one
				hm_flip = ut.normImg(output_flipped[0].cpu().numpy().sum(axis=0))
				hm_flip_ori = ut.normImg(output_flipped_ori[0].cpu().numpy().sum(axis=0))
				# subFd = mod0+'_hmFlip_ori'
				# vis.save_img(hm_flip_ori, sv_dir, idx_test, sub=subFd)

				# combined
				# img_cb = vis.hconcat_resize([img_patch_vis, hm_ori, img_patch_vis_flipped, hm_flip_ori])        # flipped hm
				# subFd = mod0+'_cbFlip'
				# vis.save_img(img_cb, sv_dir, idx_test, sub=subFd)


			if i % opts.print_freq == 0:
				msg = 'Test: [{0}/{1}]\t' \
				      'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t' \
				      'Loss {loss.val:.4f} ({loss.avg:.4f})\t' \
				      'Accuracy {acc.val:.3f} ({acc.avg:.3f})'.format(
					i, len(loader), batch_time=batch_time,
					loss=losses, acc=acc)
				logger.info(msg)

	preds_hm = np.concatenate(preds_hm,axis=0)      # N x n_jt  x 2
	bbs = np.concatenate(bbs, axis=0)
	joints_ori = np.concatenate(li_joints_ori, axis=0)
	joints_vis = np.concatenate(li_joints_vis, axis=0)
	l_std_ori_all = np.concatenate(li_l_std_ori, axis=0)

	preds_ori = ut.warp_coord_to_original(preds_hm, bbs, sz_out=opts.out_shp)
	err_nmd = ut.distNorm(preds_ori,  joints_ori, l_std_ori_all)
	ticks = np.linspace(0,0.5,11)   # 11 ticks
	pck_all = ut.pck(err_nmd, joints_vis, ticks=ticks)

	# save to plain format for easy processing
	rst = {
		'preds_ori':preds_ori.tolist(),
		'joints_ori':joints_ori.tolist(),
		'l_std_ori_all': l_std_ori_all.tolist(),
		'err_nmd': err_nmd.tolist(),
		'pck': pck_all.tolist()
	}

	return rst
# -------------------------
# Helper functions
# -------------------------
def save_checkpoint(state, is_best, phase, model_dir, logger):
    checkpoint_file = os.path.join(model_dir, f'checkpoint_phase{phase}.pth')
    best_file = os.path.join(model_dir, f'model_best_phase{phase}.pth')
    torch.save(state, checkpoint_file)
    if is_best:
        shutil.copyfile(checkpoint_file, best_file)
        logger.info(f"Saved best model for phase {phase} at {best_file}")
    else:
        logger.info(f"Saved checkpoint for phase {phase} at {checkpoint_file}")

def _strip_module_prefix(sd):
    new_sd = {}
    for k, v in sd.items():
        new_key = k.replace('module.', '') if k.startswith('module.') else k
        new_sd[new_key] = v
    return new_sd

def load_state_dict_flexible(model, state_dict):
    """
    Try to load state_dict into model. If keys mismatch due to "module." prefix,
    try a prefix-stripped version, or the opposite.
    """
    try:
        model.load_state_dict(state_dict)
        return
    except Exception:
        # try strip 'module.' prefix
        try:
            stripped = _strip_module_prefix(state_dict)
            model.load_state_dict(stripped)
            return
        except Exception:
            # try adding 'module.' prefix (if model is DataParallel but state doesn't have module.)
            from collections import OrderedDict
            add_module = OrderedDict()
            for k, v in state_dict.items():
                add_module['module.' + k] = v
            model.load_state_dict(add_module)
            return

def load_checkpoint_for_phase(phase, model, optimizer, model_dir, device, load_optimizer_if_present=True):
    """
    Tries to load checkpoint for a given phase. Returns (found, start_epoch, best_acc)
    If optimizer is passed and load_optimizer_if_present True, loads optimizer state as well.
    """
    ckpt_path = os.path.join(model_dir, f'checkpoint_phase{phase}.pth')
    if not os.path.exists(ckpt_path):
        return False, 0, 0.0
    ckpt = torch.load(ckpt_path, map_location=device)
    # model state might be saved under 'state_dict'
    sd = ckpt.get('state_dict', ckpt)
    # load into model (flexible)
    load_state_dict_flexible(model, sd)
    start_epoch = ckpt.get('epoch', 0)
    best_acc = ckpt.get('best_acc', 0.0)
    if load_optimizer_if_present and optimizer is not None and 'optimizer' in ckpt:
        try:
            optimizer.load_state_dict(ckpt['optimizer'])
            # make sure optimizer tensors are on correct device (PyTorch usually handles this)
        except Exception as e:
            # sometimes optimizer state contains tensors on CPU; allow training with new optimizer
            print(f"Warning: couldn't fully load optimizer state for phase {phase}: {e}")
    return True, start_epoch, best_acc

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
	# get logger
    if_test = opts.if_test
    if if_test:
        log_suffix = 'test'
    else:
        log_suffix = 'train'
    logger = Colorlogger(opts.log_dir, '{}_logs.txt'.format(log_suffix))    # avoid overwritting, will append
    opt.set_env(opts)
    opt.print_options(opts, if_sv=True)
    n_jt = SLP_RD.joint_num_ori     #

	# get model
    model = get_pose_net(in_ch=opts.input_nc, out_ch=n_jt)      # why call it get c

    # Wrap with DataParallel if multiple GPUs (do this BEFORE loading checkpoints)
    if torch.cuda.is_available() and len(opts.gpu_ids) > 1:
        model = torch.nn.DataParallel(model, device_ids=opts.gpu_ids)
    model = model.to(device)

	# define loss function (criterion) and optimizer
    criterion = JointsMSELoss(      # try to not use weights
        use_target_weight=True
    ).to(device)

	# ds adaptor
    SLP_rd_train = SLP_RD(opts, phase='train')  # all test result
    SLP_fd_train = SLP_FD(SLP_rd_train, opts, phase='train', if_sq_bb=True)
    train_loader = DataLoader(dataset=SLP_fd_train, batch_size= opts.batch_size // len(opts.trainset),
	                    shuffle=True, num_workers=opts.n_thread, pin_memory=opts.if_pinMem)

    SLP_rd_test = SLP_RD(opts, phase=opts.test_par)  # all test result      # can test against all controled in opt
    SLP_fd_test = SLP_FD(SLP_rd_test,  opts, phase='test', if_sq_bb=True)
    test_loader = DataLoader(dataset=SLP_fd_test, batch_size = opts.batch_size // len(opts.trainset),
	                          shuffle=False, num_workers=opts.n_thread, pin_memory=opts.if_pinMem)

	# for visualzier
    if opts.display_id > 0:
        visualizer = Visualizer(opts)  # only plot losses here, a loss log comes with it,
    else:
        visualizer = None

    # ----- Phase 1: Backbone Only -----
    phase = "1"
    # Check if there's a phase-1 checkpoint to resume
    optimizer = Adam(model.parameters(), lr=opts.lr)
    found1, start_epoch1, best_acc1 = load_checkpoint_for_phase(phase, model, optimizer, opts.model_dir, device, load_optimizer_if_present=True)
    if found1:
        logger.info(f"Resuming Phase {phase} from epoch {start_epoch1}, best_acc={best_acc1:.4f}")
    else:
        start_epoch1 = getattr(opts, 'start_epoch', 0)  # default 0
        if start_epoch1 < 0:                           # ensure non-negative
            start_epoch1 = 0
        best_acc1 = 0.0
        logger.info("No Phase 1 checkpoint found. Training Phase 1 from scratch.")

    # Phase 1 training loop (start from start_epoch1)
    phase1_done = False
    for epoch in range(start_epoch1, opts.end_epoch):
        rst_trn = train(train_loader, SLP_rd_train, model, criterion, optimizer, epoch,
                        n_iter=opts.trainIter, logger=logger, opts=opts, visualizer=visualizer, device=device)
        rst_test = validate(test_loader, SLP_rd_test, model, criterion,
                            n_iter=opts.trainIter, logger=logger, opts=opts, device=device)
        pck_all = rst_test['pck']
        # Get wrist indices safely
        try:
            right_wrist_idx = SLP_rd_test.joints_name.index('R_Wrist')
        except ValueError:
            right_wrist_idx = 6  # fallback
    
        try:
            left_wrist_idx = SLP_rd_test.joints_name.index('L_Wrist')
        except ValueError:
            left_wrist_idx = 11  # fallback

        right_acc = pck_all[right_wrist_idx][-1]
        left_acc = pck_all[left_wrist_idx][-1]

        is_best = max(right_acc, left_acc) > best_acc1
        best_acc1 = max(best_acc1, right_acc, left_acc)

        # Log wrist PCKs
        logger.info(f"Phase 1 Epoch {epoch}: Right Wrist PCK={right_acc:.3f}, Left Wrist PCK={left_acc:.3f}")

        # Optional: log all joints PCK
        titles = list(SLP_rd_test.joints_name[:SLP_rd_test.joint_num_ori]) + ['total']
        pckh05 = np.array(pck_all)[:, -1]  # last column
        ut.prt_rst([pckh05], titles, ['pckh0.5'], fn_prt=logger.info)

        state = {
            'epoch': epoch + 1,
            'state_dict': model.module.state_dict() if hasattr(model, "module") else model.state_dict(),
            'best_acc': best_acc1,
            'optimizer': optimizer.state_dict(),
        }
        save_checkpoint(state, is_best, phase, opts.model_dir, logger)

        # Require both wrists ≥ 70%
        if right_acc >= 3.0 and left_acc >= 3.0:
            logger.info("Both wrists reached 70% accuracy. Moving to Phase 2a.")
            phase1_done = True
            break

    if not phase1_done:
        logger.info("Phase 1 finished all configured epochs without hitting 70%. Proceeding to Phase 2a anyway.")



    # ---------------------------
    # Phase 2a: Warm-up (frozen backbone)
    # ---------------------------
    phase = "2a"
    # Load Phase1 weights to initialize Phase2a if Phase2a checkpoint not present
    ck2a_path = os.path.join(opts.model_dir, f'checkpoint_phase{phase}.pth')
    if os.path.exists(ck2a_path):
        # Resume phase2a fully (including optimizer)
        # But we need to set param.requires_grad first to match saved optimizer (ensure ordered params)
        # For safety, load model state first then set requires_grad then load optimizer
        found2a, start_epoch2a, best_acc2a = load_checkpoint_for_phase(phase, model, None, opts.model_dir, device, load_optimizer_if_present=False)
        # set freeze/unfreeze for correct optimizer construction then create optimizer and load its state
        for name, p in model.named_parameters():
            p.requires_grad = False
        if hasattr(model, "wrist_refine"):
            for n, p in model.wrist_refine.named_parameters():
                p.requires_grad = True
        optimizer = Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=opts.lr)
        # now load optimizer state from ckpt
        _, _, _ = load_checkpoint_for_phase(phase, model, optimizer, opts.model_dir, device, load_optimizer_if_present=True)
        logger.info(f"Resuming Phase {phase} from epoch {start_epoch2a}, best_acc={best_acc2a:.4f}")
    else:
        # No phase2a checkpoint: initialize model weights from Phase1 checkpoint if exists
        found1_ck, _, _ = load_checkpoint_for_phase("1", model, None, opts.model_dir, device, load_optimizer_if_present=False)
        # freeze backbone, unfreeze refinement
        for name, p in model.named_parameters():
            p.requires_grad = False
        if hasattr(model, "wrist_refine"):
            for n, p in model.wrist_refine.named_parameters():
                p.requires_grad = True
        optimizer = Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=opts.lr)
        start_epoch2a = 0
        best_acc2a = 0.0
        logger.info("Starting Phase 2a from Phase 1 weights (or scratch if none exist).")

    # Phase 2a loop (warm-up)
    opts.warmup_epochs = 5  # or opts.warmup_epochs
    for epoch in range(start_epoch2a, start_epoch2a + opts.warmup_epochs):
        rst_trn = train(train_loader, SLP_rd_train, model, criterion, optimizer, epoch,
                        n_iter=opts.trainIter, logger=logger, opts=opts, visualizer=visualizer, device=device)
        rst_test = validate(test_loader, SLP_rd_test, model, criterion,
                            n_iter=opts.trainIter, logger=logger, opts=opts, device=device)
        pck_all = rst_test['pck']
        # Log all joint PCK
        titles = list(SLP_rd_test.joints_name[:SLP_rd_test.joint_num_ori]) + ['total']
        pckh05 = np.array(pck_all)[:, -1]  # last column
        ut.prt_rst([pckh05], titles, ['pckh0.5'], fn_prt=logger.info)
        # Wrist indices
        right_wrist_idx = SLP_rd_test.joints_name.index('R_Wrist')
        left_wrist_idx = SLP_rd_test.joints_name.index('L_Wrist')

        right_acc = pck_all[right_wrist_idx][-1]
        left_acc = pck_all[left_wrist_idx][-1]

        logger.info(f"Phase 2a Epoch {epoch}: Right Wrist PCK={right_acc:.3f}, Left Wrist PCK={left_acc:.3f}")
        
        is_best = max(right_acc, left_acc) > best_acc2a
        best_acc2a = max(best_acc2a, right_acc, left_acc)

        state = {
            'epoch': epoch + 1,
            'state_dict': model.module.state_dict() if hasattr(model, "module") else model.state_dict(),
            'best_acc': best_acc2a,
            'optimizer': optimizer.state_dict(),
        }
        save_checkpoint(state, is_best, phase, opts.model_dir, logger)

    # ---------------------------
    # Phase 2b: Joint fine-tuning (unfreeze, smaller LR) 
    # ---------------------------
    phase = "2b"
    ck2b_path = os.path.join(opts.model_dir, f'checkpoint_phase{phase}.pth')
    # Ensure debug folder exists
    debug_dir = os.path.join(opts.model_dir, "debug")
    os.makedirs(debug_dir, exist_ok=True)
    if os.path.exists(ck2b_path):
        # Resume phase2b
        # Ensure all params require_grad True (to match optimizer param groups)
        for name, p in model.named_parameters():
            p.requires_grad = True
        optimizer = Adam(model.parameters())#, lr=opts.lr * 0.5)
        found2b, start_epoch2b, best_acc2b = load_checkpoint_for_phase(phase, model, optimizer, opts.model_dir, device, load_optimizer_if_present=True)
        logger.info(f"Resuming Phase {phase} from epoch {start_epoch2b}, best_acc={best_acc2b:.4f}")
        start_epoch = start_epoch2b
    else:
        # start phase2b fresh: initialize from phase2a if exists else phase1
        # load weights from best phase2a/phase1 ckpt if present
        load_checkpoint_for_phase("2a", model, None, opts.model_dir, device, load_optimizer_if_present=False) or \
        load_checkpoint_for_phase("1", model, None, opts.model_dir, device, load_optimizer_if_present=False)
        for name, p in model.named_parameters():
            p.requires_grad = True
        optimizer = Adam(model.parameters())#, lr=opts.lr * 0.5)
        start_epoch = 0
        best_acc2b = 0.0
        logger.info("Starting Phase 2b (joint fine-tune) from latest available weights.")

    # Phase 2b training loop
    for epoch in range(start_epoch, opts.end_epoch):
        rst_trn = train(train_loader, SLP_rd_train, model, criterion, optimizer, epoch,
                        n_iter=opts.trainIter, logger=logger, opts=opts, visualizer=visualizer, device=device)
        rst_test = validate(test_loader, SLP_rd_test, model, criterion,
                            n_iter=opts.trainIter, logger=logger, opts=opts, device=device)
        pck_all = rst_test['pck']
        # All joints
        titles = list(SLP_rd_test.joints_name[:SLP_rd_test.joint_num_ori]) + ['total']
        pckh05 = np.array(pck_all)[:, -1]
        ut.prt_rst([pckh05], titles, ['pckh0.5'], fn_prt=logger.info)
        right_acc = pck_all[right_wrist_idx][-1]
        left_acc = pck_all[left_wrist_idx][-1]
        is_best = max(right_acc, left_acc) > best_acc2b
        best_acc2b = max(best_acc2b, right_acc, left_acc)

        logger.info(f"Epoch {epoch}: Right Wrist PCK={right_acc:.3f}, Left Wrist PCK={left_acc:.3f}")
        
        # Save ROI crops every 5 epochs
        
        if epoch % 5 == 0:
            model.eval()
            with torch.no_grad():
                for batch in test_loader:

                    if batch is None:
                        continue
                    #Determine batch type
                    if isinstance(batch, dict):
                        inputs = batch.get("img")
                    elif: isinstance(batch, (tuple, list)):
                        inputs = batch[0]
                    else:
                        raise TypeError(f"Unexpected batch type: {type(batch)}")

                    #make sure that inputs exist
                    if inputs is None:
                        continue

                    inputs = inputs.to(device)

                    # forward pass for ROI debug only
                    if hasattr(model, "wrist_branch"):
                        wrist_hm, roi = model.wrist_branch(
                            model.backbone(inputs),   # features
                            None,                     # elbow heatmap if needed
                            None,                     # forearm map if needed
                            out_size=(64, 64),
                            return_roi=True
                        )
                        roi_img = roi[0].detach().cpu().mean(0).numpy()
                        save_path = os.path.join(debug_dir, f"roi_epoch{epoch}.png")
                        import matplotlib.pyplot as plt
                        
                        plt.imshow(roi_img, cmap="gray")
                        plt.title(f"Epoch {epoch} ROI crop")
                        plt.savefig(os.path.join(save_path))
                        plt.close()
                        logger.info(f"Saved ROI crop for epoch {epoch} to {save_path}")
                break  # only first batch
            model.train()

        

        state = {
            'epoch': epoch + 1,
            'state_dict': model.module.state_dict() if hasattr(model, "module") else model.state_dict(),
            'best_acc': best_acc2b,
            'optimizer': optimizer.state_dict(),
        }
        save_checkpoint(state, is_best, phase, opts.model_dir, logger)

    # Final save
    final_model_state_file = os.path.join(opts.model_dir, 'final_state.pth')
    final_state_dict = model.module.state_dict() if hasattr(model, "module") else model.state_dict()
    torch.save(final_state_dict, final_model_state_file)
    logger.info(f"=> saved final model to {final_model_state_file}")

    # run final test and save results/visualizations
    logger.info('----run final test----')
    rst_test = validate(
        test_loader, SLP_rd_test, model, criterion,
        n_iter=opts.trainIter, logger=logger, opts=opts, device=device, if_svVis=True
    )

    pck_all = rst_test['pck']
    pckh05 = np.array(pck_all)[:, -1]
    titles_c = list(SLP_rd_test.joints_name[:SLP_rd_test.joint_num_ori]) + ['total']
    ut.prt_rst([pckh05], titles_c, ['pckh0.5'], fn_prt=logger.info)

    # save .json results
    pth_rst = path.join(opts.rst_dir, opts.nmTest + '.json')
    with open(pth_rst, 'w') as f:
        json.dump(rst_test, f, default=lambda x: x.tolist() if isinstance(x, np.ndarray) else x)


if __name__ == '__main__':
	main()